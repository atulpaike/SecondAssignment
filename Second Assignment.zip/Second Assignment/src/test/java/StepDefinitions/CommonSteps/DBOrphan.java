import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.sql.*;

public class DataBaseTesting {

   private Connection connection;
   private static Statement statement;
   private static ResultSet rs;

Given(/^Establish a database connection$/) 
    public void Establish_a_database_connection() {
            String databaseURL = "jdbc:mysql://localhost:3306/easy";
            String user = "root";
            String password = "root";
            connection = null;
            try {
                Class.forName("com.mysql.jdbc.Driver");
                System.out.println("Connecting to Database...");
                connection = DriverManager.getConnection(databaseURL, user, password);
                if (connection != null) {
                    System.out.println("Connected to the Database...");
                }
            } catch (SQLException ex) {
               ex.printStackTrace();
            }
            catch (ClassNotFoundException ex) {
               ex.printStackTrace();
            }
    }

And(/^Execute query to get Orphans in first table$/) 
void Execute_query_to_get_Orphans_in_first_table() {
  @rs = @connection.query("SELECT A.* FROM A LEFT JOIN B ON (A.C = B.C) WHERE B.C IS NULL");
end 
while(rs.next()){
                int EmpId= rs.getInt("EmpId");
                String EmpName= rs.getString("EmpName");
                String EmpAddress=rs.getString(3);
                String EmpDept=rs.getString("EmpDept");
                Double EmpSal= rs.getDouble(5);
                System.out.println(EmpId+"\t"+EmpName+"\t"+EmpAddress+"\t"+EmpSal+"\t"+EmpDept);
}
}

And(/^Execute query to get Orphans in Second table$/) 
void Execute_query_to_get_Orphans_in_Second_table(){
  @rs = @connection.query("SELECT A.* FROM A RIGHT JOIN B ON (A.C = B.C) WHERE A.C IS NULL");
while(rs.next()){
                int EmpId= rs.getInt("EmpId");
                String EmpName= rs.getString("EmpName");
                String EmpAddress=rs.getString(3);
                String EmpDept=rs.getString("EmpDept");
                Double EmpSal= rs.getDouble(5);
                System.out.println(EmpId+"\t"+EmpName+"\t"+EmpAddress+"\t"+EmpSal+"\t"+EmpDept);
}
end 

And(/^Execute query to get Primary keys and column names for data breaks$/) 
void Execute_query_to_get_Primary_keys_and_column_names_for_data_breaks(){
  @rs = @connection.query("SELECT A.*, B.* FROM A FULL JOIN B ON (A.C = B.C) WHERE A.C IS NULL OR B.C IS NULL");
while(rs.next()){
                int EmpId= rs.getInt("EmpId");
                String EmpName= rs.getString("EmpName");
                String EmpAddress=rs.getString(3);
                String EmpDept=rs.getString("EmpDept");
                Double EmpSal= rs.getDouble(5);
                System.out.println(EmpId+"\t"+EmpName+"\t"+EmpAddress+"\t"+EmpSal+"\t"+EmpDept);
}
end 

@AfterClass
    public void tearDown() {
      if (connection != null) {
                try {
                    System.out.println("Closing Database Connection...");
                    connection.close();
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }
            }
      }
 }s
